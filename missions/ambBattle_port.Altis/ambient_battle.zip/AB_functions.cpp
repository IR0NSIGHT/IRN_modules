class CfgFunctions
{
	class IRN //my tag class
	{
        class myCategory {
            class calcSoundPos {file = "WOLF_Modules\ambient_battle\functions\fn_calcSoundPos.sqf";};
			class testFunction  {file = "WOLF_Modules\ambient_battle\functions\fn_test.sqf";};
            class spawnSalvo {file = "WOLF_Modules\ambient_battle\functions\fn_spawnSalvo.sqf"};
			class spawnTracer {file = "WOLF_Modules\ambient_battle\functions\fn_spawnTracer.sqf"};
			class randomVector {file = "WOLF_Modules\ambient_battle\functions\fn_randomVector.sqf"};
			class explosionLight {file = "WOLF_Modules\ambient_battle\functions\fn_explosionLight.sqf"};
			class killLights {file = "WOLF_Modules\ambient_battle\functions\fn_killLights.sqf"};
			class interpolate {file = "WOLF_Modules\ambient_battle\functions\fn_interpolate.sqf"};
			class travelTime {file = "WOLF_Modules\ambient_battle\functions\fn_travelTime.sqf"};
			class delayedSound {file = "WOLF_Modules\ambient_battle\functions\fn_delayedSound.sqf"};
        };
    };
};